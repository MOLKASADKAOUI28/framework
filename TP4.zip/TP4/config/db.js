const mongoose = require('mongoose');
const username= procecc.env.ATLAS_USERNAME;
const pw = procecc.env.ATLAS_PASSWORD;
const uri= 'mongodb+srv://amenallahbenhassine:<db_password>@project1.eggxl.mongodb.net/'

const connectDB = async () => {
    try {
        await mongoose.connect(uri) 
          
        .then(()=> console.log("MongoDB connected..."))
        .catch(err => console.log("something went wrong when connecting"))
    } catch (error) {
        console.error("erreur de connexion à mongoBD:",error.message);
        process.exit(1);
    }
};

module.exports = connectDB;