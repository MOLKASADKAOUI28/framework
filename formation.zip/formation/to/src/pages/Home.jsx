import Header from "../components/header"
import Main from "../components/main"
import { useState } from "react"
function Home()
{
const[tasks,setTasks]=useState([''])

return(
    <>
    <Header tasks={tasks} setTasks={setTasks} />
    
</>
    
)
}
export default Home