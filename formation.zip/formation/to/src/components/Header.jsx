import { useState } from 'react'
export default function Header({tasks,setTasks}){

    const [task,setTask]=useState("")

        function getValue(e){
         setTask(e.target.value)
          
    }

    function add(){
        setTasks(prev=>[...prev])
    }      
   
    }

    return(
        <header>
            <h1>To do list</h1>
            <section>
                <input onChange={getValue} value={task} type="text" name="text" id="text" />
                <button> onClick=add</button>
            </section>
            <section>
                <p>12/12/2024</p>
                <p>total: {0}</p>
            </section>
        </header>
        

    )

