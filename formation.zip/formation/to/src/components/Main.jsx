export default function Main({tasks}){



 return(
      <main>
        {
            tasks.map(item=><p>item</p>)
        }
      
      
      </main>  

    )
}
